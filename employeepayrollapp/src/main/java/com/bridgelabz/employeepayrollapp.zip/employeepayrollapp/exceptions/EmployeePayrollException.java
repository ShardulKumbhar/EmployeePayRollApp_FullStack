package com.bridgelabz.employeepayrollapp.exceptions;

public class EmployeePayrollException  extends RuntimeException {
    public EmployeePayrollException(String message){
        super(message);
    }
}
